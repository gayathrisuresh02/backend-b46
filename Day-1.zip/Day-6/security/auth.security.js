const userModel = require("../model/user.model");

const userRegistration = (req, res) =>
{
    const { username, email, password } = req.body;
   
   let userExists = userModel.find(data => data.email === email);
    if (userExists)
    {
        return res.status(404).json({messgae:"user already exists"})
    }
    let userPin = Math.floor(1000 + Math.random() * 9999);
   const userdata = {
       id: Date.now(),
       username,
       email,
       password,
       userPin
    }
    userModel.push(userdata);
    console.log(userPin)
    return res.status(200).json({message:"user registered successfully",userdata})

}

const userLogin = (req, res) => {
    const { email, password, userPin } = req.body;
    let userlog = userModel.find(data => data.email === email && data.password === password);
    if (!userlog)
    {
        return res.status(404).json({message:"invalid email and pwd"})
    }
    if (userlog.userPin != userPin)
    {
        return res.status(404).json({ message: "invalid pin" })

    }
    return res.status(200).json({message:"login successfull",userlog})

}
module.exports = { userRegistration,userLogin };