const express = require("express");

const app = express();

const port = 9000;
const userRouter = require("./router/user.router");
app.use(express.json());
app.use("/auth", userRouter);
app.listen(port, () => {
    console.log(`${port} server running successfully`)
})