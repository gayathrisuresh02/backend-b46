const express = require("express");
const router = express.Router();
const userSecurity = require("../security/auth.security");
router.post("/register", userSecurity.userRegistration);
router.post("/login", userSecurity.userLogin);

module.exports = router;

