const { add, sub,div } = require("./Sample");
console.log("Addition=:",add(5, 6));
console.log("addition=:",add(8, 6));

console.log("subtraction=:", sub(5, 4));

console.log("division=:", div(10,2));