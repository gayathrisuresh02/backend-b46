function add(x,y)
{
   
    let z = x + y;
    return z;
}
function sub(x, y) {
  let z = x - y;
  return z;
}
function div(x, y) {
  let z = x / y;
  return z;
}
module.exports = { add, sub,div };
