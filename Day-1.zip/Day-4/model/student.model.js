const students = [{ id: 1001, fname: "Gayathri", email: "gayu02@gmail.com" }];

module.exports = students;