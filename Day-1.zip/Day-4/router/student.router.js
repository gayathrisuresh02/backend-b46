
const express = require("express");
const router = express.Router();
const studentController = require("../controller/student.controller");
router.get("/details", studentController.getStudentData);
router.post("/save", studentController.createStudent);


module.exports = router;