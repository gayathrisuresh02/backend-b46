const studentModel = require("../model/student.model");

const getStudentData = (req, res) => {
    if (studentModel.length == "")
    {
                return res
                  .status(400)
                  .json({ message: "student data not available" });

    }
    return res.json(studentModel);
}
const createStudent = (req, res) =>
{
    let { fname, email } = req.body;

    if (fname == " ")
    {
        return res.status(400).json({ message: "name cannot be empty" })
    }
    if (email == " ") {
      return res.status(400).json({ message: "email cannot be empty" });
    }
    const studentdata = {
        id:Date.now().toString(),
        fname,
        email

    }
    studentModel.push(studentdata);
    return res.status(200).json({message:"added student data"});

}

module.exports = { getStudentData,createStudent };