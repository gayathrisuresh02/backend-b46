const express = require("express");
const app = express();
const studentRouter=require("./router/student.router")
const port = 5000;
app.use(express.json());

app.use(studentRouter);

app.listen(port, () => {
    console.log("server is running ",port)
})