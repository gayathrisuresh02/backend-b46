const express = require("express");
const app = express();
const port = 8080;
app.get("/users", (req, res) => {
    res.json({message:"user data display"})
})
app.delete("/remove", (req, res) => {
  res.json({ message: "user data deleted" });
});
app.post("/create", (req, res) => {
  res.json({ message: "user data added" });
});
app.put("/update", (req, res) => {
  res.json({ message: "user data updated" });
});
app.listen(port, () => {
    console.log("application running succesfully",port)
})