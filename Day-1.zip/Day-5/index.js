const express = require("express");
const patientRouter = require("./router/patient.router");
const app = express();
app.use(express.json());
app.use(patientRouter);
const port = 4000;
app.listen(port, () => {
    console.log(`${port} port number  application running successfully`)
})