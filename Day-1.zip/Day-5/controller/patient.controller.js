const patientModel = require("../model/patient.model");

const getPatientDetails = (req, res) => {
    if (patientModel.length == "")
    {
        return res.status(404).json({message:"patient details not found"})
    }
    return res.status(200).json(patientModel);
}
const getPatientById = (req, res) => {
    const id = req.params.id;
    const searchPatient = patientModel.find(data => data.id == id);
    if (!searchPatient)
    {
        return res.status(404).json({message:"patient details not found"})
    }
    return res.json(searchPatient);

};

const addpatient = (req, res) => {
    const { pname, age, mobile } = req.body;

    if (pname == "" || age == "" || mobile == "")
    {
        return res.status(404).json({message:"patient details cannot be empty"})
    }
    const patientdata = {
        id:Date.now(),
        pname,
        age,
        mobile
    }
    patientModel.push(patientdata)
    return res
      .status(200)
      .json({ message: "patient data added successfully", patientdata });
};

const updatePatient = (req, res) => {
    const { pname, age, mobile } = req.body;
  const id = req.params.id;
  const searchPatient = patientModel.find((data) => data.id == id);
  if (!searchPatient) {
    return res.status(404).json({ message: "patient details not found" });
    }
    searchPatient.pname = pname ||searchPatient.pname;
    searchPatient.age = age || searchPatient.age;
    searchPatient.mobile = mobile || searchPatient.mobile;
  
  return res.status(200).json({message:"patient data updated",searchPatient});
};

const deletePatient = (req, res) => {
  const id = req.params.id;
  const patient = patientModel.findIndex((data) => data.id == id);//1001 1
  if (patient.id==-1) {
    return res.status(404).json({ message: "patient details not found" });
    }
    patientModel.splice(patient,1)//
  return res.json({ messgae: "patient data removed", patient });
};
module.exports = { getPatientDetails,getPatientById,addpatient,updatePatient,deletePatient };