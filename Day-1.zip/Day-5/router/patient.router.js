const express = require("express");
const router = express.Router();
const patientController = require("../controller/patient.controller");
router.get("/view", patientController.getPatientDetails);
router.get("/view/:id", patientController.getPatientById);
router.post("/save", patientController.addpatient);
router.put("/update/:id", patientController.updatePatient);
router.delete("/remove/:id", patientController.deletePatient);
module.exports = router;