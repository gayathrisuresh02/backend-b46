const patients = [
  { id: 1001, pname: "lalitha", age: 45, mobile: "9047740149" },
  { id: 1002, pname: "kavi", age: 35, mobile: "8056664288" },
];

module.exports = patients;