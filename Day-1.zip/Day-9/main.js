const express = require("express");
require("dotenv").config();
const app = express();

const dbConnection = require("./config/dbConnection.config");
dbConnection();
app.listen(process.env.port, () => {
    console.log(`${process.env.port} server running successfully`)
})