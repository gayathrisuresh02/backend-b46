const mongoose = require("mongoose");
const userSchema = mongoose.Schema({
    Firstname: {
        type: String,
        required: true
    },
    Age: {
        type: Number,
        required:true
    },
    email: {
        type: String,
        required: true,
        unique:true
    }
})
const user = mongoose.model("users", userSchema)

module.exports = user;