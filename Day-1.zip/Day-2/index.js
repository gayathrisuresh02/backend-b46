const cube = require("./Cube");
console.log(cube(3));
console.log(cube(4));
