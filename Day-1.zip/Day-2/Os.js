const os = require("os");
console.log(os.platform());
console.log(os.arch())
console.log(os.networkInterfaces())
console.log(os.release())
console.log(os.uptime())