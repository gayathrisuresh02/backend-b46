const EvenEmitter = require("events");

const chatEvent = new EvenEmitter();

chatEvent.on("Message", (user, message) =>
{
    console.log(`user,${user},${message}`)
    
})
chatEvent.emit("Message","Haridoss", "join the class immediately")
chatEvent.emit("Message", "Gayathrimam"," i will join soon");
const paymentEvent = new EvenEmitter();

paymentEvent.once("payment", (amount,message) => {
  console.log(`user,${amount},${message}`);
});
paymentEvent.emit("payment", "20,000", "credited successfully");
paymentEvent.emit("payment", " $20,000", " credited successfully");
