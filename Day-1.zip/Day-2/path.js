const path = require("node:path");

console.log(__filename);
console.log(__dirname);
console.log(path.extname(__filename))
console.log(path.dirname(__filename))