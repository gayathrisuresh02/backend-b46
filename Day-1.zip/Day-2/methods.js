const app = require("http");

app.createServer(function (req, res) {
    res.write("hello")
    res.end();
    
}).listen(5000);
