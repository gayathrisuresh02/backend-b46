const fs = require("fs");
fs.writeFile("demo.txt", "Welcome to JS", (err) => {
    if (err)
    {
        console.log("file not found ")
        return;
    }
    console.log("file successfully created")
})