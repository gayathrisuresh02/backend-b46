const express = require("express");
const router = express.Router();
const userController = require("../controller/userController");
router.get("/view", userController.getUsers);
router.post("/save", userController.addUsers);
router.put("/update/:id", userController.updateUsers);
router.delete("/remove/:id", userController.deleteUsers);

module.exports = router;
