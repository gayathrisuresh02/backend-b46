const userModel = require("../model/usermodel");

const getUsers = async (req, res) => {
    try {
        const viewuser = await userModel.find();
        
        return res.json({sucess:true,viewuser});

    }
    catch (err)
    {
        return res.status(500).json("fetch user data failed")
    }
}

const addUsers = async (req, res) => {
    try {
        const { firstname, age, email } = req.body
        if (firstname == "" || age == "" || email == "")
        {
            res.status(404).json({message:"userdata required"})
        }
        const adduser = await userModel.create({ firstname, age, email })
           return res.status(200).json(adduser);

    }
    catch (err)
    {
        return res.status(500).json({message:"useradded task failed"})
    }
}

//req.params.id,re.body,{new:true}
const updateUsers = async (req, res) => {
    try {
        const updateuser = await userModel.findByIdAndUpdate(
            req.params.id,
            req.body,
            { new: true },
        );
        return res.status(200).json(updateuser);
    }
    catch (err) {
        return res.status(500).json({message:"user data updated failed"})
    }
}


const deleteUsers = async (req, res) => {
    try {
        const deleteuser = await  userModel.findByIdAndDelete(req.params.id);

        return res.status(200).json({ message: "user data deleted", deleteuser });
    }
    catch (err)
    {
        return res.status(500).json({message:"userdata delete operation failed"})
    }
}
module.exports = { getUsers,addUsers,updateUsers,deleteUsers };