const mongoose = require("mongoose");
const userSchema = mongoose.Schema({
    firstname: {
        type: String,
        required: true
    },
    age: {
        type: Number,
        required:true
    },
    email: {
        type: String,
        required: true,
        unique:true
    }
})
const user = mongoose.model("users", userSchema)

module.exports = user;