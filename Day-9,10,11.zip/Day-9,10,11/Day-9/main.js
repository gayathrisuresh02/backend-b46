const express = require("express");
require("dotenv").config();
const userRouter=require("./router/userRouter")
const app = express();
app.use(express.json())
app.use("/users", userRouter);

const dbConnection = require("./config/dbConnection.config");
dbConnection();
app.listen(process.env.port, () => {
    console.log(`${process.env.port} server running successfully`)
})